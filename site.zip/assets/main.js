// Meniu valdymas. Jokių tinklo užklausų, slapukų ar saugyklos.
(function(){
  var btn=document.querySelector('.nav-toggle'), menu=document.getElementById('meniu');
  function close(){menu.classList.remove('open');btn.setAttribute('aria-expanded','false');btn.textContent='Meniu';}
  if(btn&&menu){
    btn.addEventListener('click',function(){var o=menu.classList.toggle('open');btn.setAttribute('aria-expanded',o?'true':'false');btn.textContent=o?'Uždaryti':'Meniu';});
    menu.addEventListener('click',function(e){if(e.target.tagName==='A')close();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&menu.classList.contains('open')){close();btn.focus();}});
  }
  // Švelnus atsiradimas ir skaitikliai – tik jei vartotojas neprašo mažinti judesio.
  var still=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var els=document.querySelectorAll('[data-reveal]');
  if(!still&&'IntersectionObserver' in window&&els.length){
    document.documentElement.classList.add('rv');
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');count(e.target);io.unobserve(e.target);}});},{rootMargin:'0px 0px -8% 0px'});
    els.forEach(function(el){io.observe(el);});
  }
  function count(root){
    root.querySelectorAll('[data-count]').forEach(function(n){
      if(n.getAttribute('data-plain'))return;var to=+n.getAttribute('data-count'),t0=null;
      function step(t){if(!t0)t0=t;var k=Math.min(1,(t-t0)/900);n.textContent=Math.round(to*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(step);}
      requestAnimationFrame(step);
    });
  }
})();
